#include "Arduino.h"
#include "Sensors.h"

//---> Constructor
Sensors::Sensors()
{
}

//---> Set and get for the AdaFruit.
void Sensors::setAdaFruit(Adafruit_ADS1115 ads1115)
{
  _ads1115 = ads1115;
}
Adafruit_ADS1115 Sensors::getAdaFruit()
{
  return _ads1115;
}

//---> Get for the sensors.
int Sensors::getSalinityValue()
{
  //--->  Salinity sensor calibration variables
  const int chSalinity = 0;      // Channel where the salinity sensor is to be connected
  const int withoutSalt = 22250; // Measurement without salt in the environment
  const int withSalt = 30275;    // Measured with salt in the environment

  //---> Obtaining and refining the result.
  int salinityRAW = take_measure(chSalinity);
  int salinityValue = map(salinityRAW, withoutSalt, withSalt, 0, 100);
  return salinityValue;
}
int Sensors::getHumidityValue()
{
  //--->  Humidity sensor calibration variables
  const int chHumidity = 3;     // Channel where the humidity sensor is to be connected
  const int airValue = 30000;   // Dry value
  const int waterValue = 16000; // Value in water

  //---> Obtaining and refining the result.
  int humidityRAW = take_measure(chHumidity);
  //int humidityValue = humidityRAW;
  int humidityValue = 100 * airValue / (airValue - waterValue) - humidityRAW * 100 / (airValue - waterValue);
  return humidityValue;
}
int Sensors::getTemperatureValue()
{
  //--->  Temperature sensor calibration variables
  const int chTemperature = 1;
  const float tempCoeff = 0.79;
  const float slopeLine = 0.0345;
  //---> Obtaining and refining the result.
  float temperatureRAW = take_measure(chTemperature);
  int temperatureValue = ((((temperatureRAW * 4.096) / (pow(2, 15) - 1)) - tempCoeff) / slopeLine);
  return temperatureValue;
}
int Sensors::getLightnessValue()
{
  //--->  Light sensor calibration variables
  const int chLightness = 2;      // Channel where the Light sensor is to be connected
  const int darkness = 65;        // Darkness value
  const int maxLightness = 29500; // Max Lightness value
  //---> Obtaining and refining the result.
  int lightnessRAW = take_measure(chLightness);
  int lightnessValue = map(lightnessRAW, darkness, maxLightness, 0, 100);
  return lightnessValue;
}

float Sensors::take_measure(int numChannel)
{
  const int powerPin = 5;  // GPIO 5 is used to power the salinity probe
  const int nMeasure = 20; // Measure variables

  int i;
  float reading, sum; // We use float to have as much precision as possible

  reading = 0.0;
  sum = 0.0;

  switch (numChannel)
  {
  case 0:
    for (i = 1; i <= nMeasure; i++)
    {
      digitalWrite(powerPin, HIGH);                    // We give power to the sensor
      delay(100);                                      // We wait for the sensor to initialize
      sum += _ads1115.readADC_SingleEnded(numChannel); // We read the values
      digitalWrite(powerPin, LOW);                     // We turn off the sensor
      delay(10);                                       // We wait for the results
    }
    break;
  case 1:
  case 2:
  case 3:
    // Serial.println("Soy yo, Concha. Entro");
    for (i = 1; i <= nMeasure; i++)
    {
      sum += _ads1115.readADC_SingleEnded(numChannel); // We read the values
    }
    break;
  default:
    Serial.println("Se ha producido un error inesperado, contacte con el administrador del dispositivo y muestrele el codigo de error \"ZEBRA\"");
    delay(1000);
  }

  reading = sum / float(nMeasure);
  return reading;
}