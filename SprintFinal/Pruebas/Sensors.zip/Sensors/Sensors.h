#ifndef Sensors_h
#define Sensors_h

#include "Arduino.h"
#include <Wire.h>             // Library to use the I2C BUS
#include <Adafruit_ADS1X15.h> // ADS1115 Library

class Sensors
{
private:
  //---> Support method for obtaining sensor measurements
  float take_measure(int numChannel);
  //---> Variable encapsulation
  Adafruit_ADS1115 _ads1115;

public:
  //---> Constructor
  Sensors();

  //---> Set and get for the AdaFruit.
  void setAdaFruit(Adafruit_ADS1115 ads1115);
  Adafruit_ADS1115 getAdaFruit();

  //---> Get from the sensors.
  int getHumidityValue();
  int getSalinityValue();
  int getTemperatureValue();
  int getLightnessValue();
};

#endif
